# Situs status & promo HarPOS

Situs statis untuk **GitHub Pages**. Screenshot fitur ada di folder `img/`.

## Publish
1. Buat repo GitHub (public).
2. Upload **semua file** di folder ini ke branch `main` (root).
3. Settings → Pages → branch `main` / root.
4. URL: `https://USERNAME.github.io/REPO/`

Update status: edit `status.json`.
Kontak default: WhatsApp 0855-5133-3370.
